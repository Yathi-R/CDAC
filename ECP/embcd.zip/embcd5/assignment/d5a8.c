#include <stdio.h>
int main() {
    char arr[100];
    char ch;
    int i = 0;
    while ( i<100 && (ch = getchar()) != '\n' && ch != EOF) {
      
        arr[i] = ch;
        i++;
    }
    arr[i] = '\0';
    printf("\n %s\n",arr);
}