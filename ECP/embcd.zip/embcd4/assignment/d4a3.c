/*Average of n element in the array*/

#include<stdio.h>

int main(){
    
    int n;

    //Getting size of array from user
    printf("Enter the number of elements for array:");
    scanf("%d", &n);

    int numbers[n];

    //Getting elements of the array from user
    printf("Enter the elements of integer array:\n");
    for(int i = 0; i < n; i++){
        scanf("%d", &numbers[i]);
    }

    //Calculating & displaying the Average of n array elements
    int sum = 0;
    
    for(int j=0; j<n; j++){
        sum += numbers[j];
    }

    float average = (float) sum / n;
    
    printf("The Average of the n elements in the array is %0.2f\n", average);

 
return 0;
}